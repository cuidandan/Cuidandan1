/******************************************************************************/
/* Copyright (C) cd.com, stu@USTC,2014-2015                                   */
/*                                                                            */
/* FILE NAME            : test.c                                              */
/* PRINCIPAL AUTHOR     : Cuidandan                                           */
/* SUBSYSTEM NAME       : menu                                                */
/* MODULE NAME          : menu                                                */
/* LANGUAGE             : c                                                   */
/* TARGET ENVIRONMENT   : ANY                                                 */
/* DATE OF FIRST RELEASE: 2014/09/15                                          */
/* DESCRIPTION          : Unit test for menu program                          */
/******************************************************************************/

/*
 * Revision log;
 *  
 * Created by Cuidandan,2014/09/30
 *  
 */

#include<stdio.h>

#include"tmenu.h"

#define debug


int results[3]={1,1,1};
char *info[3]=
{
    "test report",
    "TC1 Addcmd",
    "TC2 delcmd"
};

int main()
{
    int i;
    tLinkTable *p=NULL;
    int res = Delcmd(p);
    if(res==failure)
    {
       debug("TC1 SUCCESS\n");
       results[1]=0;
    }
    
    tLinkTableNode *pNode=NULL;
    int ret = Addcmd(p,pNode);
    if(ret==failure)
    {
      debug("TC2 SUCCESS\n");
      results[2] =1;
    }


    /* test report */
    printf("test report\n");
    for( i=1;i<=2;i++)
    {
       if(results[i]== 1)
       {
          printf("Testcase Number%d F - %s\n",i,info[i]);
       }
    }
}
