/******************************************************************************/
/* Copyright (C) cd.com, stu@USTC,2014-2015                                   */
/*                                                                            */
/* FILE NAME            : tmenu.h                                             */
/* PRINCIPAL AUTHOR     : Cuidandan                                           */
/* SUBSYSTEM NAME       : menu                                                */
/* MODULE NAME          : menu                                                */
/* LANGUAGE             : c                                                   */
/* TARGET ENVIRONMENT   : ANY                                                 */
/* DATE OF FIRST RELEASE: 2014/09/15                                          */
/* DESCRIPTION          : Unit test for menu program                          */
/******************************************************************************/

/*
 * Revision log;
 *  
 * Created by Cuidandan,2014/09/30
 *  
 */

#define success 0
#define failure (-1)
#include<stdio.h>

typedef struct LinkTableNode
{
    struct LinkTableNode *pNext;
}tLinkTableNode;


typedef struct LinkTable tLinkTable;
int Addcmd(tLinkTable* head,tLinkTableNode *pNode);

int Delcmd(tLinkTable* head);



