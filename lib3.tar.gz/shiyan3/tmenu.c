/******************************************************************************/
/* Copyright (C) cd.com, stu@USTC,2014-2015                                   */
/*                                                                            */
/* FILE NAME            : tmenu.c                                             */
/* PRINCIPAL AUTHOR     : Cuidandan                                           */
/* SUBSYSTEM NAME       : menu                                                */
/* MODULE NAME          : menu                                                */
/* LANGUAGE             : c                                                   */
/* TARGET ENVIRONMENT   : ANY                                                 */
/* DATE OF FIRST RELEASE: 2014/09/15                                          */
/* DESCRIPTION          : Unit test for menu program                          */
/******************************************************************************/

/*
 * Revision log;
 *  
 * Created by Cuidandan,2014/09/30
 *  
 */

#include<stdio.h>
#include"tmenu.h"



int  Addcmd(tLinkTable* head,tLinkTableNode * pNode)
{
    if(head==NULL||pNode==NULL)
    {
       return failure;
    }
    
    return success;   
}

int  Delcmd(tLinkTable* head)
{
    if(head==NULL)
    {
       return failure;
    }
    
    return success;
}
