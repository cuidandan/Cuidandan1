/******************************************************************************/
/* Copyright (C) cd.com, stu@USTC,2014-2015                                   */
/*                                                                            */
/* FILE NAME            : menu.c                                              */
/* PRINCIPAL AUTHOR     : Cuidandan                                           */
/* SUBSYSTEM NAME       : menu                                                */
/* MODULE NAME          : menu                                                */
/* LANGUAGE             : c                                                   */
/* TARGET ENVIRONMENT   : ANY                                                 */
/* DATE OF FIRST RELEASE: 2014/09/15                                          */
/* DESCRIPTION          : This is a menu program                              */
/******************************************************************************/

/*
 * Revision log;
 *  
 * Created by Cuidandan,2014/09/15
 *  
 */ 
    
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"linktable.h"

int Help();

#define DESC_LEN   1024
#define cmd_num    10
#define cmd_len    128
#define desc_len   255
/* data struct and operations */

typedef struct DataNode
{
    tLinkTableNode * pNext;
    char cmd[cmd_len];
    char desc[desc_len];
    int   (*handler)();
}tDataNode;

/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head,char* cmd )
{ 
    tDataNode *pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
       if(!strcmp(pNode->cmd,cmd))
       {
        return pNode;
       }        
       pNode= (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    
     return NULL;
}

/* show all cmd in the list */
int ShowAllCmd(tLinkTable *head)
{
    tDataNode *pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
       printf("%s - %s\n", pNode->cmd, pNode->desc);
       pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;

}

static tDataNode data[]=
{
    {NULL,"help","this is help cmd!",Help},
    {NULL,"version","menu program v1.0",NULL}
};


/* Addcmd to the tLinktable */
tLinkTable* Addcmd(tLinkTable* head,char* cmd,char* desc)
{

    tDataNode *p = (tDataNode*)malloc(sizeof(tDataNode));
    strcpy(p->cmd,cmd);
    strcpy(p->desc,desc);
    AddLinkTableNode(head,(tLinkTableNode*)p);
    return head;
    
}   
/* DelCmd from the tLinkTable */
tLinkTable* DelCmd(tLinkTable* head,char* cmd)
{
    tDataNode *p=FindCmd(head,cmd);
    if(p==NULL)
    {
       printf("The Command dosen't exits!\n");
       return NULL;
    }
    else
    {
       DelLinkTableNode(head,(tLinkTableNode*)p);
       return head;
    }

}
/* Call Addcmd Function  */
int  CallAddcmd(tLinkTable* head)
{
    /*tLinkTable*  head = CreateLinkTable();*/
    char cmd[cmd_len];
    char desc[desc_len];
    tDataNode* p=(tDataNode*)malloc(sizeof(tDataNode));
    printf("Please Add  cmd & desc:\n ");
    scanf("%s",p->cmd);
    gets(p->desc);
    Addcmd(head,p->cmd,p->desc);
    return 0;
}

/* Call DelCmd Function*/
int  CallDelCmd(tLinkTable* head)
{
   
    char cmd[cmd_len];
    printf("Input a command to Delete:");
    scanf("%s",cmd);
    DelCmd(head,cmd);
    return 0;

}


/* menu program */


tLinkTable * head = NULL; 
main()
{
    head = CreateLinkTable();
    CallAddcmd(head);
    char cmd[cmd_len];
    AddLinkTableNode(head,(tLinkTableNode *)&data[0]);
    AddLinkTableNode(head,(tLinkTableNode *)&data[1]);
  /*cmd line begins */
   while(1)
   {
    printf("Input a cmd Number:");
    scanf("%s",cmd);
    tDataNode *p = FindCmd(head,cmd);
    if(p==NULL)
    {
      printf("This a wrong cmd!\n");
      continue;
    }    
    printf("%s - %s\n",p->cmd,p->desc);
    if(p->handler!=NULL)
    {
      p->handler();
    }
    CallDelCmd(head);
   }
}

int Help()
{
    ShowAllCmd(head);
    return 0;
}
