/******************************************************************************/
/* Copyright (C) cd.com, stu@USTC,2014-2015                                   */
/*                                                                            */
/* FILE NAME            : menu.h                                              */
/* PRINCIPAL AUTHOR     : Cuidandan                                           */
/* SUBSYSTEM NAME       : menu                                                */
/* MODULE NAME          : menu                                                */
/* LANGUAGE             : c                                                   */
/* TARGET ENVIRONMENT   : ANY                                                 */
/* DATE OF FIRST RELEASE: 2014/09/15                                          */
/* DESCRIPTION          : define of menu program                              */
/******************************************************************************/

/*
 * Revision log;
 *  
 * Created by Cuidandan,2014/09/15
 *  
 */
#ifndef _MENU_H_
#define _MENU_H_


#include <pthread.h>
#include"linktable.h"


    
#define SUCCESS 0
#define FAILURE (-1)



/* Addcmd to the LinkTable */
tLinkTable * Addcmd(tLinkTable * head,char* cmd, char* desc);

/* DelCmd from the LinkTable */

tLinkTable * DelCmd(tLinkTable* head,char* cmd);


  















#endif

